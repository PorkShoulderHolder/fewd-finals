for(var i=0; i < 36; i++){
	$("div").html("<div></div>");
};

$(function() {
  $( ".block" ).draggable();
  $( ".grid" ).droppable({
    drop: function( event, ui ) {
      $( this )
        .addClass( "ui-state-highlight" )
        .html( "Dropped!" );
    }
  });
});
